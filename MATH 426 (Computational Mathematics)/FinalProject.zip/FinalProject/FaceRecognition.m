%%
%{

An image set is used to manage large collections of images
it maintains a heierarchal relationship between the image sets

Database0 contains 10 images * 40 people. They are pgm 92x112
Database0 contains 10 images * 417 people. They are pgm 480x640

Database0 is pretty easy to testPartition against since the illumination is
constant, the only variations are slight differences in the poses/expressions of the
subjects.  There are 4680 HoG features

Database1 has a higher resolution per picture, so there are more HoG
features per picture (167796)

%}
clear
validResponse = 0;

while validResponse == 0
    prompt = 'Which database do you want to use? (Database0 / Database1) "q" to quit ';
    database = input(prompt,'s');
    
    switch database
        case "Database0"
            validResponse = 1;
            numFeatures = 4680;
            break;
        case "Database1"
            validResponse = 1;
            numFeatures = 167796;
        case "q"
            return;
        otherwise
            disp("Invalid Response");
    end
end
    



imageDatabase = imageSet(database,'recursive');

%%  Display Query Image and Database Side-Side
personToQuery = 1;
galleryImage = read(imageDatabase(personToQuery),1);
%figure;

for i=1:size(imageDatabase,2)
imageList(i) = imageDatabase(i).ImageLocation(5);
end


%%Partition the database
%{

Before extracting features, we split the database into a trainingPartition sets to
learn how to distinguish features, and a testPartition set to testPartition against

This splits the partitions the faces, 80% of the faces are used to train
on, then the remaining 20% are used to testPartition

%}
[trainingPartition,testPartition] = partition(imageDatabase,[0.8 0.2]);

%% Extract and display Histogram of Oriented Gradient Features for single face 
person = 5;
[hogFeature, visualization]= ...
    extractHOGFeatures(read(trainingPartition(person),1));
figure;

%% Extract HOG Features for trainingPartition set 
%{

HoG features encode the edge information (including the directionality)

trainingPartition features size results from the 80/20 split

trainingPartition label is used to determine which features belong to which person
in the database


%}
trainingPartitionFeatures = zeros(size(trainingPartition,2)*trainingPartition(1).Count, numFeatures);
featureCount = 1;

for i=1:size(trainingPartition,2)
    for j = 1:trainingPartition(i).Count
        trainingPartitionFeatures(featureCount,:) = extractHOGFeatures(read(trainingPartition(i),j));
        trainingPartitionLabel{featureCount} = trainingPartition(i).Description;    
        featureCount = featureCount + 1;
    end
    personIndex{i} = trainingPartition(i).Description;
end

%%
%{

ecoc classifer is used to learn how to discriminate between the different
faces


fitcecoc fits multiclass models for support vector machines or other classifiers
it returns a full, trained, multiclass

%}
classifiers = fitcecoc(trainingPartitionFeatures,trainingPartitionLabel);

%% testPartition images from the testPartition paration 
person = 1;
queryImage = read(testPartition(person),1);
queryFeatures = extractHOGFeatures(queryImage);
subjectLabel = predict(classifiers,queryFeatures);
booleanIndex = strcmp(subjectLabel, personIndex);
integerIndex = find(booleanIndex);

%% testPartition First 5 People from testPartition Set
figureNum = 1;

for person=1:5
    for j = 1:testPartition(person).Count
        queryImage = read(testPartition(person),j);
        queryFeatures = extractHOGFeatures(queryImage);
        subjectLabel = predict(classifiers,queryFeatures);
        booleanIndex = strcmp(subjectLabel, personIndex);
        integerIndex = find(booleanIndex);
        subplot(1,2,1);imshow(imresize(queryImage,3));title('Query Face');
        subplot(1,2,2);imshow(imresize(read(trainingPartition(integerIndex),1),3));title('Matched Class');
        
        figureNum = figureNum+2;
        
    end
    figure;
    figureNum = 1;
end
